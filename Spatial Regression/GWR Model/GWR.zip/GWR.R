######################## Importing Packages ########################
library(spgwr)
library(rgdal)
library(tmap)
library(spdep)
library(grid)

######################## Data Manipulation ########################
MT10 = read.csv('MT10.csv')
MT10 = MT10[, c(1:455, 483, 456:482,484:492)]

#Introducing regression formula
vars = names(MT10)[457:491]
formula = as.formula(paste("Mortality_Rate ~ ", paste(vars, collapse = "+")))

model1 = lm(formula,MT10)
summary(model1)
plot(model1, which=3)

#Reading shape file
County.Map = readOGR(dsn = ".", layer = "CO_CARTO")
MT10 = cbind(coordinates(County.Map),MT10)
colnames(MT10)[1] = "x"
colnames(MT10)[2] = "y"

resids = residuals(model1)

#Identifying missing values in MT10
missing.rows.columns = data.frame(which(is.na(MT10), arr.ind = TRUE))
#Rows with missing values in MT10
na.index = c(unique(missing.rows.columns[,1]))
#Omitting missing values in shape file and MT10
County.Map@data = County.Map@data[-c(na.index),]
County.Map@polygons = County.Map@polygons[-c(na.index)]
County.Map@plotOrder = County.Map@plotOrder[-c(na.index)]
MT10 = na.omit(MT10)


colours = c("dark blue", "blue", "red", "dark red")
#here it is assumed that your eastings and northings coordinates are stored in columns called x and y in your dataframe
map.resids = SpatialPointsDataFrame(data = data.frame(resids), coords = MT10[,1:2]) 
spplot(map.resids, cuts=quantile(resids), col.regions=colours, cex=1) 

######################## GWR Model ########################
#calculate kernel bandwidth (CV method)
GWRbandwidth = gwr.sel(formula, data = MT10, coords = as.matrix(MT10[,1:2]),adapt = T) 

#run the first gwr model
gwr.start.time = Sys.time()
gwr.model = gwr(formula, data = MT10, coords = as.matrix(MT10[,1:2]),
                adapt = GWRbandwidth, hatmatrix = TRUE, se.fit = TRUE)

gwr.end.time = Sys.time()
gwr.time = gwr.end.time - gwr.start.time
gwr.time
#print the results of the model
gwr.model

# #calculate kernel bandwidth (AIC method)
# GWRbandwidth = gwr.sel(formula, data = MT10, coords = as.matrix(MT10[,1:2]),
#                        adapt = T, method = "aic") 
# 
# #run the second gwr model
# gwr.start.time = Sys.time()
# gwr.model = gwr(formula, data = MT10, coords = as.matrix(MT10[,1:2]),
#                 adapt = GWRbandwidth, hatmatrix = TRUE, se.fit = TRUE)
# 
# gwr.end.time = Sys.time()
# gwr.time = gwr.end.time - gwr.start.time
# gwr.time
# #print the results of the model
# gwr.model

######################## GWR Model Adequacy ########################
gwr.SST = sum((MT10$Mortality_Rate - mean(MT10$Mortality_Rate))^2)
gwr.RSS = gwr.model$results$rss
gwr.SSE = sum((MT10$Mortality_Rate - gwr.model$SDF$pred)^2)  #Same as RSS
gwr.R_squared = 1 - (gwr.RSS/ gwr.SST)
p = ncol(MT10[459:493])
N = nrow(MT10)
gwr.Adj.R_squared = 1 - ((1-gwr.R_squared)*(N-1))/(N-p-1)

gwr.SST
gwr.RSS
gwr.R_squared
gwr.Adj.R_squared

######################## GWR Model Visualization ########################
results = as.data.frame(gwr.model$SDF)
head(results)

#attach coefficients & local R2 to original dataframe
MT10$coefPOVALL_2018 = results$POVALL_2018
MT10$coefMedian_Household_Income_2018 = results$Median_Household_Income_2018
MT10$coefpercent_physically_inactive = results$percent_physically_inactive
MT10$localR2 = results$localR2

gwr.map = cbind(County.Map, as.matrix(MT10))

gwr.map = st_as_sf(gwr.map)

#Mapping Local R2
qtm(gwr.map, fill = "localR2", text.size = 3) +
  tmap_options(max.categories = 10) 

#Spatial distribution of POVALL_2018
map1 <- tm_shape(gwr.map) + 
  tm_fill("POVALL_2018",
          n = 5,
          style = "pretty",
          title = "Poverty Spatial Distribution")  +
  tm_layout(frame = FALSE,
            legend.text.size = 0.5,
            legend.title.size = 2) +
  tmap_options(max.categories = 5)
map1

#Coefficients of POVALL_2018
map2 <- tm_shape(gwr.map) +
  tm_fill("coefPOVALL_2018",
          n = 5,
          style = "quantile",
          title = "Poverty Coefficient") +
  tm_layout(frame = FALSE,
            legend.text.size = 0.5,
            legend.title.size = 0.6)
map2

#Spatial distribution of Median_Household_Income_2018
map3 <- tm_shape(gwr.map) + 
  tm_fill("Median_Household_Income_2018",
          n = 5,
          style = "quantile",
          title = "Median Household Income Spatial distribution")  +
  tm_layout(frame = FALSE,
            legend.text.size = 0.5,
            legend.title.size = 0.6)
map3

#Coefficients of Median_Household_Income_2018
map4 <- tm_shape(gwr.map) +
  tm_fill("coefMedian_Household_Income_2018",
          n = 5,
          style = "quantile",
          title = "Median Household Income Coefficients") +
  tm_layout(frame = FALSE,
            legend.text.size = 0.5,
            legend.title.size = 0.6)
map4

# creates a clear grid
grid.newpage()

# assigns the cell size of the grid, in this case 2 by 2
pushViewport(viewport(layout=grid.layout(2,2)))

# prints a map object into a defined cell   
print(map1, vp=viewport(layout.pos.col = 1, layout.pos.row =1))
print(map2, vp=viewport(layout.pos.col = 2, layout.pos.row =1))
print(map3, vp=viewport(layout.pos.col = 1, layout.pos.row =2))
print(map4, vp=viewport(layout.pos.col = 2, layout.pos.row =2))